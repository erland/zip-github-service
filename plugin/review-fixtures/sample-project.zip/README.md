# zip-GitHub review sample

This is a harmless static fixture for Marketplace review of the stage_zip MCP tool.
